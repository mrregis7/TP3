package testes;

public class StringTeste {

}
