package testes;

public class EstagiarioTeste {

}
