package exceptions;

public class EstagiarioInexistenteException extends Exception {

	public EstagiarioInexistenteException(String mensagem) {
		super(mensagem);
	}
}