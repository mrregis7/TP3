package exceptions;

public class NomeIncompletoException extends Exception {

	public NomeIncompletoException(String mensagem) {
		super(mensagem);
	}
}