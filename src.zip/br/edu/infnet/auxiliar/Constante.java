package br.edu.infnet.auxiliar;

public class Constante {

}
