package auxiliar;

public class Constante {

	public static final float SALARIO_LIMITE_POBRE = 50000;
	public static final float SALARIO_LIMITE_RICO = 100000;
	public static final int QTDE = 3;
	public static final Integer[] OPCOES = {1,2,3,4};
	public static final int MAIOR_IDADE = 18;
	public static final float SALARIO_MINIMO = 1045;
	public static final int QTDE_ESTAGIOS = 1000;
	//final de constante e sem "private" pra todos de "testes" possam ver
}
