package testes;

public class StringEstagiarioTeste {

}
