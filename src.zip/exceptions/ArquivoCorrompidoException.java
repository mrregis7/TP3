package exceptions;

public class ArquivoCorrompidoException {

}
